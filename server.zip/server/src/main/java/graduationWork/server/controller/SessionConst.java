package graduationWork.server.controller;

public interface SessionConst {
    String LOGIN_USER = "loginUser";
}
