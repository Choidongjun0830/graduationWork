package graduationWork.server.controller;

public class adminController {
}
