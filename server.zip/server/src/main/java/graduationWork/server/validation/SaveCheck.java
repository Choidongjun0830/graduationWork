package graduationWork.server.validation;

public interface SaveCheck {
}
